import { IInputs, IOutputs } from "./generated/ManifestTypes";
import ProcessFlow from "./VisioPCF";
import * as React from "react";

export class VisioPCF implements ComponentFramework.ReactControl<IInputs, IOutputs> {

  private notifyOutputChanged!: () => void;

  private _buttonClicked = false;
  private _clickedRecordId: string | undefined;

  // Two-way bound property
  private _resetToggle = false;

  // Output: submenu action
  private _menuAction: string | null = null;

  public init(
    context: ComponentFramework.Context<IInputs>,
    notifyOutputChanged: () => void
  ): void {
    this.notifyOutputChanged = notifyOutputChanged;

    // read initial resetToggle value
    this._resetToggle = context.parameters.resetToggle.raw ?? false;
  }

  /**
   * 🔥 Handles BOTH:
   * 1) Old behavior: (id)
   * 2) New menu behavior: (id, action)
   * 
   * ProcessFlow now always calls:
   *   onPcfButtonClick(id, action)
   */
  private handlePcfButtonClick = (id?: string, action?: string): void => {

    // ALWAYS STORE record GUID
    this._clickedRecordId = id ?? "";

    // BUTTON WAS CLICKED
    this._buttonClicked = true;

    // ⭐ If a MENU item triggered this → store menu action also
    if (action) {
      this._menuAction = action;
      console.log("Menu Action from React = ", action);
    }

    // Also PCF wants resetToggle = TRUE when PCF button/menu clicked
    this._resetToggle = true;

    this.notifyOutputChanged();
  };

  public updateView(context: ComponentFramework.Context<IInputs>): React.ReactElement {

    // Read latest Canvas value (Canvas may set resetToggle = false)
    this._resetToggle = context.parameters.resetToggle.raw ?? false;

    return React.createElement(ProcessFlow, {
      context,

      /**
       * ⚠️ IMPORTANT:
       * This MUST support (id, action) because popup menu uses 2 params
       */
      onPcfButtonClick: this.handlePcfButtonClick
    });
  }

  public getOutputs(): IOutputs {
    return {
      buttonClicked: this._buttonClicked,
      clickedRecordId: this._clickedRecordId,

      // two‑way binding
      resetToggle: this._resetToggle,

      // popup menu chosen item
      menuAction: this._menuAction ?? ""
    };
  }

  public destroy(): void {}
}