/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    sampleProperty: ComponentFramework.PropertyTypes.StringProperty;
    defaultTaskId: ComponentFramework.PropertyTypes.StringProperty;
    BaseAppUrl: ComponentFramework.PropertyTypes.StringProperty;
    resetToggle: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    resetToggleOut: ComponentFramework.PropertyTypes.TwoOptionsProperty;
}
export interface IOutputs {
    resetToggle?: boolean;
    resetToggleOut?: boolean;
    buttonClicked?: boolean;
    clickedRecordId?: string;
    menuAction?: string;
}
