// ProcessFlow.tsx
import * as React from "react";
import { useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { IInputs } from "./generated/ManifestTypes";

/* ============================
 Types
 ============================ */
export interface EntityRow {
  ey_tbl_processflowmetaid: string;
  ey_taskid: string;
  ey_name: string;
  ey_processid: string;
  ey_processcategory: string;
  ey_expectedcompletionwdnumber: number | null;
  ey_dependencystepid?: string; // semicolon delimited process IDs
  ey_processdependenciesforcontains?: string; // comma delimited fallback
  ey_processstatusid?: number;
  CurrentStatusText?: string;
  ey_expectedcompletiondatecalculated?: Date | null;
}

interface IProcessFlowProps {
  context: ComponentFramework.Context<IInputs>;
  // UPDATED: optional 'action' to pass menu item label
  onPcfButtonClick?: (id?: string, action?: string) => void;
}

type ColorType = "green" | "blue" | "yellow" | "gray" | "red";

interface StepBlock {
  key: string;
  // Store the GUID for navigation
  ey_tbl_processflowmetaid: string;
  swimlane: number;
  swimlaneLabel: string;
  timeline: number;
  title: string;
  subtitle: string;
  color: ColorType;
  workingDay: number | null;
  Status: string;
  CurrentStatusText: string;
  ey_expectedcompletiondatecalculated: Date | null;
}

interface Dependency {
  from: string; // taskId
  to: string; // taskId
  label?: string;
  color?: string;
}

interface BlockPosition {
  x: number; // Center X
  y: number; // Center Y
  w: number;
  h: number;
  key?: string; // Added key for easier logic in FlowConnectorsSVG
}

// Highlight colors
const highlightMap: Record<"selected" | "precedent" | "dependent", { bg: string; fg: string }> = {
  selected: { bg: "#3297ED", fg: "#fff" }, // Blue
  precedent: { bg: "#0cf7d8ff", fg: "#fff" }, // Orange/Cyan (Used for Block Border)
  dependent: { bg: "#8911c9ff", fg: "#fff" } // Green/Purple (Used for Block Border)
};

// BASE DIMENSIONS (At Zoom 1.0)
const BASE_CARD_WIDTH = 200;
const BASE_CARD_HEIGHT = 120;
const BASE_CARD_GAP = 35;
const BASE_ROW_PADDING = 18;
// Removed negative offset; calculations now relative to the unified grid
const VERTICAL_OFFSET = 0;

const colorMap: Record<ColorType, { bg: string; fg: string }> = {
  green: { bg: "#B7DFB6", fg: "#234F1E" },
  blue: { bg: "#3297ED", fg: "#fff" },
  yellow: { bg: "#FFE699", fg: "#524803" },
  gray: { bg: "#cccccc", fg: "#222" },
  red: { bg: "#f98686ff", fg: "#530202ff" }
};

// NEW: Standard Colors for Details Panel Text
const standardStatusColors: Record<ColorType, string> = {
  green: "green", // Standard Green
  red: "red", // Standard Red
  blue: "blue", // Standard Blue
  yellow: "#e6b800", // Standard Dark Yellow/Gold (Readable on white)
  gray: "gray" // Standard Gray
};

const statusColorMap: Record<number, ColorType> = {
  1: "gray",
  2: "yellow",
  3: "green",
  4: "red",
  5: "yellow",
  6: "blue",
  7: "yellow",
};

// --- ARROW CONSTANTS (UPDATED) ---
const ARROW_THICKNESS = 1.5;
const ARROW_THICKNESS_HIGHLIGHT = 3.5; // UPDATED: Increased thickness for selected/highlighted arrows
const ARROW_SIZE_SM = 12;
const ARROW_COLOR = "#0078D4";
const ARROW_HIGHLIGHT_COLOR = "#F7630C"; // Color for a manually selected dependency line
// Use the highlight map's border colors for arrow strokes for consistency
const ARROW_PRECEDENT_COLOR = highlightMap.precedent.bg; // #0cf7d8ff (Cyan/Orange Border)
const ARROW_DEPENDENT_COLOR = highlightMap.dependent.bg; // #8911c9ff (Purple/Green Border)

/* ============================
 Utility helpers
 ============================ */
function toNumberSafe(v: any): number | null {
  if (v === null || v === undefined || v === "") return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function uniqueFirstSeen<T>(arr: T[], keyFn?: (t: T) => string): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const a of arr) {
    const k = keyFn ? keyFn(a) : String(a);
    if (!seen.has(k)) {
      seen.add(k);
      out.push(k);
    }
  }
  return out;
}

interface Payload {
  entities: EntityRow[];
}

function decompressPayload(encoded: string | undefined | null): Payload | null {
  if (!encoded) return null;
  try {
    const maybeB64 = decodeURIComponent(String(encoded));
    const json = decodeURIComponent(atob(maybeB64));
    return JSON.parse(json) as Payload;
  } catch (e) {
    try {
      const decoded = decodeURIComponent(String(encoded));
      return JSON.parse(decoded) as Payload;
    } catch (err) {
      console.warn("decompressPayload: cannot decode payload", err);
      return null;
    }
  }
}

/* ============================
 SVG Connector component helpers (UPDATED)
 ============================ */
function getNearestEdgePoints(fromPos: BlockPosition, toPos: BlockPosition, arrowSize: number): {
  start: { x: number; y: number; };
  end: { x: number; y: number; };
  isHorizontalPath: boolean;
  isForward: boolean;
} {
  const deltaX = Math.abs(toPos.x - fromPos.x);
  const deltaY = Math.abs(toPos.y - fromPos.y);

  let startX, startY, endX, endY;
  let isHorizontalPath = true; // Default to horizontal-first path
  let isForward = true; // Default flow direction (Right or Down)

  if (deltaX >= deltaY) {
    // Primarily Horizontal connection (L-R or R-L)
    isHorizontalPath = true;
    isForward = fromPos.x < toPos.x; // Left to Right (Forward)

    // Start: Right edge if forward, Left edge if backward
    startX = isForward ? fromPos.x + fromPos.w / 2 : fromPos.x - fromPos.w / 2;
    startY = fromPos.y;

    // End: Left edge if forward, Right edge if backward
    endX = isForward ? toPos.x - toPos.w / 2 : toPos.x + toPos.w / 2;
    endY = toPos.y;
  } else {
    // Primarily Vertical connection (T-B or B-T)
    isHorizontalPath = false;
    isForward = fromPos.y < toPos.y; // Top to Bottom (Forward)

    // Start: Bottom edge if forward, Top edge if backward
    startX = fromPos.x;
    startY = isForward ? fromPos.y + fromPos.h / 2 : fromPos.y - fromPos.h / 2;

    // End: Top edge if forward, Bottom edge if backward
    endX = toPos.x;
    endY = isForward ? toPos.y - toPos.h / 2 : toPos.y + toPos.h / 2;
  }

  return {
    start: { x: startX, y: startY },
    end: { x: endX, y: endY },
    isHorizontalPath,
    isForward
  };
}

function getStepEdgePath(
  start: { x: number; y: number },
  end: { x: number; y: number },
  isForward: boolean,
  isHorizontalPath: boolean
): string {
  const ARROW_SIZE_SM = 12;

  if (isHorizontalPath) {
    const arrowEndOffset = isForward ? -ARROW_SIZE_SM : ARROW_SIZE_SM;
    const arrowEndX = end.x + arrowEndOffset;
    const midX = (start.x + arrowEndX) / 2;

    return `M ${start.x} ${start.y}
 L ${midX} ${start.y}
 L ${midX} ${end.y}
 L ${arrowEndX} ${end.y}`;
  } else {
    const arrowEndOffset = isForward ? -ARROW_SIZE_SM : ARROW_SIZE_SM;
    const arrowEndY = end.y + arrowEndOffset;
    const midY = (start.y + arrowEndY) / 2;

    return `M ${start.x} ${start.y}
 L ${start.x} ${midY}
 L ${end.x} ${midY}
 L ${end.x} ${arrowEndY}`;
  }
}

const FlowConnectorsSVG: React.FC<{
  dependencies: Dependency[];
  blockPositions: Record<string, BlockPosition>;
  selectedDependencyKey: string | null;
  onSelectDependency?: (key: string | null) => void;
  precedentTaskIds: Set<string>;
  dependentTaskIds: Set<string>;
  selectedTaskKey: string | null;
}> = ({ dependencies, blockPositions, selectedDependencyKey, onSelectDependency, selectedTaskKey }) => {
  if (!dependencies || dependencies.length === 0 || Object.keys(blockPositions).length === 0) return null;

  const unhighlightedDeps: Dependency[] = [];
  const highlightedDeps: Dependency[] = [];
  dependencies.forEach(dep => {
    const key = `${dep.from}→${dep.to}`;
    const isSelectedDependency = selectedDependencyKey === key;
    const isIncomingToSelected = selectedTaskKey && dep.to === selectedTaskKey;
    const isOutgoingFromSelected = selectedTaskKey && dep.from === selectedTaskKey;

    if (isSelectedDependency || isIncomingToSelected || isOutgoingFromSelected) {
      highlightedDeps.push(dep);
    } else {
      unhighlightedDeps.push(dep);
    }
  });

  const renderPath = (dep: Dependency) => {
    const fromPos = blockPositions[dep.from];
    const toPos = blockPositions[dep.to];
    if (!fromPos || !toPos) return null;

    const { start, end, isHorizontalPath, isForward } = getNearestEdgePoints(fromPos, toPos, ARROW_SIZE_SM);
    const d = getStepEdgePath(start, end, isForward, isHorizontalPath);

    const key = `${dep.from}→${dep.to}`;
    const isSelectedDependency = selectedDependencyKey === key;
    const isIncomingToSelected = selectedTaskKey && dep.to === selectedTaskKey;
    const isOutgoingFromSelected = selectedTaskKey && dep.from === selectedTaskKey;

    let stroke = dep.color ?? ARROW_COLOR;
    let markerId = `arrow-default-${ARROW_SIZE_SM}`;
    let strokeWidth = ARROW_THICKNESS;

    if (isSelectedDependency) {
      stroke = ARROW_HIGHLIGHT_COLOR;
      markerId = `arrow-highlight-${ARROW_SIZE_SM}`;
      strokeWidth = ARROW_THICKNESS_HIGHLIGHT;
    } else if (isIncomingToSelected) {
      stroke = ARROW_PRECEDENT_COLOR;
      markerId = `arrow-precedent-${ARROW_SIZE_SM}`;
      strokeWidth = ARROW_THICKNESS_HIGHLIGHT;
    } else if (isOutgoingFromSelected) {
      stroke = ARROW_DEPENDENT_COLOR;
      markerId = `arrow-dependent-${ARROW_SIZE_SM}`;
      strokeWidth = ARROW_THICKNESS_HIGHLIGHT;
    }

    return (
      <g key={key} style={{ pointerEvents: "auto", cursor: "pointer" }}>
        <path
          d={d}
          fill="none"
          stroke={stroke}
          strokeWidth={strokeWidth}
          markerEnd={`url(#${markerId})`}
          onClick={(e) => {
            e.stopPropagation();
            if (onSelectDependency) onSelectDependency(key === selectedDependencyKey ? null : key);
          }}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") {
              e.preventDefault();
              if (onSelectDependency) onSelectDependency(key === selectedDependencyKey ? null : key);
            }
          }}
          tabIndex={0}
          role="button"
          aria-label={`Dependency ${dep.from} to ${dep.to}${isSelectedDependency ? " (selected)" : ""}`}
          style={{
            strokeLinejoin: "round",
            strokeLinecap: "round",
            filter: "drop-shadow(0 1px 2px rgba(0,0,0,0.12))",
            transition: "stroke 0.2s"
          }}
        />
      </g>
    );
  };

  const DefaultMarker = (
    <marker id={`arrow-default-${ARROW_SIZE_SM}`} markerWidth={ARROW_SIZE_SM} markerHeight={ARROW_SIZE_SM} refX={ARROW_SIZE_SM} refY={ARROW_SIZE_SM / 2} orient="auto" markerUnits="userSpaceOnUse">
      <polygon points={`0 0, ${ARROW_SIZE_SM} ${ARROW_SIZE_SM / 2}, 0 ${ARROW_SIZE_SM}`} fill={ARROW_COLOR} />
    </marker>
  );
  const PrecedentMarker = (
    <marker id={`arrow-precedent-${ARROW_SIZE_SM}`} markerWidth={ARROW_SIZE_SM} markerHeight={ARROW_SIZE_SM} refX={ARROW_SIZE_SM} refY={ARROW_SIZE_SM / 2} orient="auto" markerUnits="userSpaceOnUse">
      <polygon points={`0 0, ${ARROW_SIZE_SM} ${ARROW_SIZE_SM / 2}, 0 ${ARROW_SIZE_SM}`} fill={ARROW_PRECEDENT_COLOR} />
    </marker>
  );
  const DependentMarker = (
    <marker id={`arrow-dependent-${ARROW_SIZE_SM}`} markerWidth={ARROW_SIZE_SM} markerHeight={ARROW_SIZE_SM} refX={ARROW_SIZE_SM} refY={ARROW_SIZE_SM / 2} orient="auto" markerUnits="userSpaceOnUse">
      <polygon points={`0 0, ${ARROW_SIZE_SM} ${ARROW_SIZE_SM / 2}, 0 ${ARROW_SIZE_SM}`} fill={ARROW_DEPENDENT_COLOR} />
    </marker>
  );
  const SelectedDependencyMarker = (
    <marker id={`arrow-highlight-${ARROW_SIZE_SM}`} markerWidth={ARROW_SIZE_SM} markerHeight={ARROW_SIZE_SM} refX={ARROW_SIZE_SM} refY={ARROW_SIZE_SM / 2} orient="auto" markerUnits="userSpaceOnUse">
      <polygon points={`0 0, ${ARROW_SIZE_SM} ${ARROW_SIZE_SM / 2}, 0 ${ARROW_SIZE_SM}`} fill={ARROW_HIGHLIGHT_COLOR} />
    </marker>
  );

  return (
    <svg width="100%" height="100%" style={{ overflow: "visible" }}>
      <defs>
        {DefaultMarker}
        {PrecedentMarker}
        {DependentMarker}
        {SelectedDependencyMarker}
      </defs>
      {unhighlightedDeps.map(renderPath)}
      {highlightedDeps.map(renderPath)}
    </svg>
  );
};

/* ============================
 Core Builders (dynamic arrays)
 ============================ */
function buildSwimlaneLabels(entities: EntityRow[]): string[] {
  const labels = uniqueFirstSeen(entities, e => e.ey_processcategory ?? "Uncategorized");
  return labels.length ? labels : ["Uncategorized"];
}

function buildTimelineColumns(entities: EntityRow[]): string[] {
  const nums = new Set<number>();
  for (const e of entities) {
    const n = toNumberSafe(e.ey_expectedcompletionwdnumber);
    if (n !== null) nums.add(n);
  }
  const arr = Array.from(nums).sort((a, b) => a - b);
  return arr.map(n => String(n));
}

function buildStepBlocks(entities: EntityRow[], swimlaneLabels: string[], timelineColumns: string[]): StepBlock[] {
  const blocks = entities.map(e => {
    const swimlane = e.ey_processcategory ? swimlaneLabels.indexOf(e.ey_processcategory) : -1;

    const timelineIndex = e.ey_expectedcompletionwdnumber !== null && e.ey_expectedcompletionwdnumber !== undefined
      ? timelineColumns.indexOf(String(toNumberSafe(e.ey_expectedcompletionwdnumber)))
      : -1;

    const status = Number(e.ey_processstatusid) || 0;
    const color = statusColorMap[status] ?? "gray";

    const workingDay = e.ey_expectedcompletionwdnumber ?? null;
    const Status =
      (e as any).ey_processstatusid_formatted ??
      (e as any)["ey_processstatusid@OData.Community.Display.V1.FormattedValue"] ??
      "";

    const swimlaneLabel = e.ey_processcategory ?? "";
    const ey_expectedcompletiondatecalculated = e.ey_expectedcompletiondatecalculated ?? "";
    const CurrentStatusText = e.CurrentStatusText ?? "";

    return {
      key: e.ey_taskid ?? e.ey_tbl_processflowmetaid ?? "",
      ey_tbl_processflowmetaid: e.ey_tbl_processflowmetaid,
      swimlane,
      timeline: timelineIndex,
      title: e.ey_taskid ?? "",
      subtitle: e.ey_name ?? "",
      color,
      workingDay,
      Status,
      swimlaneLabel,
      CurrentStatusText,
      ey_expectedcompletiondatecalculated: e.ey_expectedcompletiondatecalculated ? new Date(e.ey_expectedcompletiondatecalculated) : null
    };
  });

  return blocks.sort((a, b) => {
    if (a.swimlane !== b.swimlane) return a.swimlane - b.swimlane;

    const wdA = a.workingDay ?? 999999;
    const wdB = b.workingDay ?? 999999;
    if (wdA !== wdB) return wdA - wdB;

    const dateA = a.ey_expectedcompletiondatecalculated ? a.ey_expectedcompletiondatecalculated.getTime() : 0;
    const dateB = b.ey_expectedcompletiondatecalculated ? b.ey_expectedcompletiondatecalculated.getTime() : 0;
    if (dateA !== dateB) return dateA - dateB;

    return a.title.localeCompare(b.title, undefined, { numeric: true, sensitivity: 'base' });
  });
}

function buildDependencies(entities: EntityRow[]): Dependency[] {
  const byProcessId = new Map<string, EntityRow>();
  const byTaskId = new Map<string, EntityRow>();

  for (const e of entities) {
    if (e.ey_processid) byProcessId.set(e.ey_processid, e);
    if (e.ey_taskid) byTaskId.set(e.ey_taskid, e);
  }

  const edges: { from: string; to: string; color: string; label?: string }[] = [];

  const pushEdgeIfValid = (fromToken: string | undefined, toToken: string | undefined, label?: string) => {
    if (!fromToken || !toToken) return;
    const fromEntity = byProcessId.get(fromToken) ?? byTaskId.get(fromToken);
    const toEntity = byProcessId.get(toToken) ?? byTaskId.get(toToken);
    if (fromEntity && toEntity && fromEntity.ey_taskid && toEntity.ey_taskid) {
      edges.push({ from: fromEntity.ey_taskid, to: toEntity.ey_taskid, color: "#0078D4", label });
    }
  };

  // Preceding edges
  for (const e of entities) {
    const raw = (e.ey_dependencystepid ?? "").trim();
    if (raw) {
      const tokens = raw.split(";").map(s => s.trim()).filter(Boolean);
      for (const t of tokens) {
        pushEdgeIfValid(t, e.ey_processid ?? e.ey_taskid);
      }
    }
  }

  // Fallback
  for (const e of entities) {
    const raw = (e as any).ey_processdependenciesforcontains ?? "";
    if (raw) {
      const tokens = String(raw).split(",").map(s => s.trim()).filter(Boolean);
      for (const t of tokens) {
        pushEdgeIfValid(t, e.ey_processid ?? e.ey_taskid);
      }
    }
  }

  // Dependent edges
  for (const e of entities) {
    const myPid = e.ey_processid;
    if (!myPid) continue;

    for (const other of entities) {
      const oDep = (other.ey_dependencystepid ?? "").trim();
      if (oDep && oDep.includes(myPid)) {
        pushEdgeIfValid(myPid, other.ey_processid ?? other.ey_taskid);
      }
      const oBack = (other as any).ey_processdependenciesforcontains ?? "";
      if (oBack && String(oBack).includes(myPid)) {
        pushEdgeIfValid(myPid, other.ey_processid ?? other.ey_taskid);
      }
    }
  }

  const dedup = new Map<string, Dependency>();
  for (const ed of edges) {
    const k = `${ed.from}\u2192${ed.to}`;
    if (!dedup.has(k)) {
      dedup.set(k, { from: ed.from, to: ed.to, color: ed.color, label: ed.label });
    }
  }
  return Array.from(dedup.values());
}

/* ============================
 Main component
 ============================ */
const ProcessFlow: React.FC<IProcessFlowProps> = ({ context, onPcfButtonClick }) => {
  const [entities, setEntities] = useState<EntityRow[]>([]);
  const [isOpen, setIsOpen] = useState(true);
  const [zoom, setZoom] = useState(0.7); // Default Zoom 70%
  const [hasUserSelected, setHasUserSelected] = useState(false);

  // === Menu overlay state (outside grid) ===
  const [menuForKey, setMenuForKey] = useState<string | null>(null);
  const [menuGuid, setMenuGuid] = useState<string | null>(null);
  const [menuPos, setMenuPos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const menuRef = useRef<HTMLDivElement | null>(null);
  const MENU_ITEMS = ["Task Information", "Task Dependencies", "Timelines"];

  const handleZoomIn = () => setZoom(prev => Math.min(prev + 0.1, 2.0));
  const handleZoomOut = () => setZoom(prev => Math.max(prev - 0.1, 0.3));

  // Data Loading
  useEffect(() => {
    const mode: any = context?.mode;

    try {
      const fp = mode?.fullPageParam;
      if (fp?.payload) {
        const parsed = decompressPayload(fp.payload);
        const arr = (parsed?.entities && Array.isArray(parsed.entities)) ? parsed.entities : (Array.isArray(parsed) ? parsed : []);
        if (arr.length) {
          const norm = arr.map((e: any) => {
            const rawStatus = e.ey_processstatusid;
            let safeStatusId = Number(rawStatus);
            if (isNaN(safeStatusId) && typeof rawStatus === 'object' && rawStatus !== null) {
              safeStatusId = Number(rawStatus.Value ?? rawStatus.value);
            }
            if (isNaN(safeStatusId)) safeStatusId = 0;

            return {
              ey_tbl_processflowmetaid: String(e.ey_tbl_processflowmetaid ?? ""),
              ey_taskid: String(e.ey_taskid ?? ""),
              ey_name: String(e.ey_name ?? ""),
              ey_processid: String(e.ey_processid ?? ""),
              ey_processcategory: String(e.ey_processcategory ?? ""),
              ey_expectedcompletionwdnumber: toNumberSafe(e.ey_expectedcompletionwdnumber),
              ey_dependencystepid: e.ey_dependencystepid ?? e.ey_processdependenciesforcontains ?? "",
              ey_processstatusid: safeStatusId,
              CurrentStatusText: String(e.CurrentStatusText ?? ""),
              ey_expectedcompletiondatecalculated: e.ey_expectedcompletiondatecalculated ? new Date(e.ey_expectedcompletiondatecalculated) : null
            };
          }) as EntityRow[];
          setEntities(norm);
          return;
        }
      }
    } catch (err) {
      console.warn("Error reading fullPageParam.payload:", err);
    }

    try {
      const raw = context?.parameters?.sampleProperty?.raw;
      if (raw) {
        const parsed = JSON.parse(raw);
        const arr = parsed.entities ?? parsed;
        if (Array.isArray(arr)) {
          const norm = arr.map((e: any) => {
            const rawStatus = e.ey_processstatusid;
            let safeStatusId = Number(rawStatus);
            if (isNaN(safeStatusId) && typeof rawStatus === 'object' && rawStatus !== null) {
              safeStatusId = Number(rawStatus.Value ?? rawStatus.value);
            }
            if (isNaN(safeStatusId)) safeStatusId = 0;

            return {
              ey_tbl_processflowmetaid: String(e.ey_tbl_processflowmetaid ?? ""),
              ey_taskid: String(e.ey_taskid ?? ""),
              ey_name: String(e.ey_name ?? ""),
              ey_processid: String(e.ey_processid ?? ""),
              ey_processcategory: String(e.ey_processcategory ?? ""),
              ey_expectedcompletionwdnumber: toNumberSafe(e.ey_expectedcompletionwdnumber),
              ey_dependencystepid: e.ey_dependencystepid ?? e.ey_processdependenciesforcontains ?? "",
              ey_processstatusid: safeStatusId,
              CurrentStatusText: String(e.CurrentStatusText ?? ""),
              ey_expectedcompletiondatecalculated: e.ey_expectedcompletiondatecalculated ? new Date(e.ey_expectedcompletiondatecalculated) : null
            };
          }) as EntityRow[];
          setEntities(norm);
          return;
        }
      }
    } catch (err) {
      console.warn("Error reading sampleProperty.raw:", err);
    }

    setEntities([]);
  }, [context, context?.parameters?.sampleProperty?.raw]);

  const swimlaneLabels = useMemo(() => buildSwimlaneLabels(entities), [entities]);
  const timelineColumns = useMemo(() => buildTimelineColumns(entities), [entities]);
  const stepBlocks = useMemo(() => buildStepBlocks(entities, swimlaneLabels, timelineColumns), [entities, swimlaneLabels, timelineColumns]);
  const dependencies = useMemo(() => buildDependencies(entities), [entities]);

  const [selected, setSelected] = useState<string | null>(null);
  const [selectedDependencyKey, setSelectedDependencyKey] = useState<string | null>(null);

  const boxRefs = useRef<Record<string, React.RefObject<HTMLDivElement>>>(
    stepBlocks.reduce((acc, s) => {
      acc[s.key] = React.createRef<HTMLDivElement>();
      return acc;
    }, {} as Record<string, React.RefObject<HTMLDivElement>>)
  );

  // Default selection from input parameter
  useEffect(() => {
    if (hasUserSelected) return;

    const defaultIdRaw = context.parameters.defaultTaskId?.raw;
    const defaultTaskId = String(defaultIdRaw ?? "").trim();

    if (defaultTaskId && stepBlocks.length > 0 && selected === null) {
      const blockToSelect = stepBlocks.find(b => b.key === defaultTaskId);
      if (blockToSelect) {
        setSelected(blockToSelect.key);
      }
    }
  }, [context.parameters.defaultTaskId, stepBlocks, selected, hasUserSelected]);

  const gridContainerRef = useRef<HTMLDivElement | null>(null);
  const [blockPositions, setBlockPositions] = useState<Record<string, BlockPosition>>({});

  // Dynamic dimensions based on zoom
  const scaledCardWidth = BASE_CARD_WIDTH * zoom;
  const scaledCardHeight = BASE_CARD_HEIGHT * zoom;
  const scaledGap = BASE_CARD_GAP * zoom;
  const scaledRowHeight = scaledCardHeight + BASE_ROW_PADDING;

  const gridColumnWidths = useMemo(() => {
    return timelineColumns.map((col, colIdx) => {
      let maxCards = 0;
      for (let rowIdx = 0; rowIdx < swimlaneLabels.length; rowIdx++) {
        const blocks = stepBlocks.filter(b => b.swimlane === rowIdx && b.timeline === colIdx);
        if (blocks.length > maxCards) maxCards = blocks.length;
      }
      if (maxCards === 0) maxCards = 1;
      return scaledCardWidth * maxCards + scaledGap * (maxCards - 1) + 20;
    });
  }, [timelineColumns, swimlaneLabels, stepBlocks, scaledCardWidth, scaledGap]);

  const gridTemplateColumns = `170px ${gridColumnWidths.map(w => `${w}px`).join(" ")}`;
  const gridTemplateRows = `max-content repeat(${swimlaneLabels.length}, ${scaledRowHeight}px)`;

  useLayoutEffect(() => {
    const grid = gridContainerRef.current;
    if (!grid) return;

    const updatePositions = () => {
      const rectGrid = grid.getBoundingClientRect();
      const pos: Record<string, BlockPosition> = {};

      for (const block of stepBlocks) {
        const ref = boxRefs.current[block.key];
        if (ref?.current) {
          const r = ref.current.getBoundingClientRect();
          pos[block.key] = {
            x: r.left - rectGrid.left + grid.scrollLeft + r.width / 2,
            y: r.top - rectGrid.top + grid.scrollTop + r.height / 2 + VERTICAL_OFFSET,
            w: r.width,
            h: r.height,
            key: block.key
          };
        }
      }
      setBlockPositions(pos);
    };

    const t = setTimeout(updatePositions, 0);
    grid.addEventListener("scroll", updatePositions);
    window.addEventListener("resize", updatePositions);

    return () => {
      clearTimeout(t);
      grid.removeEventListener("scroll", updatePositions);
      window.removeEventListener("resize", updatePositions);
    };
  }, [stepBlocks, selected, gridTemplateColumns, gridTemplateRows, zoom]);

  const { precedentTaskIds, dependentTaskIds } = useMemo(() => {
    if (!selected) return { precedentTaskIds: new Set<string>(), dependentTaskIds: new Set<string>() };
    const precedentTaskIds = new Set<string>(dependencies.filter(dep => dep.to === selected).map(dep => dep.from));
    const dependentTaskIds = new Set<string>(dependencies.filter(dep => dep.from === selected).map(dep => dep.to));
    return { precedentTaskIds, dependentTaskIds };
  }, [selected, dependencies]);

  const selectedBlock = useMemo(() => stepBlocks.find(b => b.key === selected), [selected, stepBlocks]);

  // === Menu helpers (outside grid overlay) ===
  //type MenuPick = { id: string; action: string };

  
interface MenuPick {
  id: string;
  action: string;
}


  const onPcfMenuPick = (pick: MenuPick) => {
    if (pick.action === "Open record") {
      try {
        const pcfContext = context as any as { page?: { getClientUrl: () => string } };
        const baseUrl = (pcfContext?.page?.getClientUrl?.() ?? window.location.origin).replace(/\/$/, "");
        const recordUrl = `${baseUrl}/main.aspx?etn=ey_tbl_processflowmeta&id=${pick.id}&pagetype=entityrecord`;
        window.open(recordUrl, "_blank");
      } catch {
        // ignore
      }
    }
    onPcfButtonClick?.(pick.id, pick.action);
    setMenuForKey(null);
    setMenuGuid(null);
  };

  // Close popup on outside click / ESC
  useEffect(() => {
    if (!menuForKey) return;

    const onMouseDown = (e: MouseEvent) => {
      const n = e.target as Node;
      if (menuRef.current && menuRef.current.contains(n)) return; // click inside menu
      setMenuForKey(null);
      setMenuGuid(null);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setMenuForKey(null);
        setMenuGuid(null);
      }
    };

    window.addEventListener("mousedown", onMouseDown, true);
    window.addEventListener("keydown", onKey, true);
    return () => {
      window.removeEventListener("mousedown", onMouseDown, true);
      window.removeEventListener("keydown", onKey, true);
    };
  }, [menuForKey]);

  const handleOpenRecord = (targetKey: string) => {
    const targetBlock = stepBlocks.find(b => b.key === targetKey);
    if (!targetBlock || !targetBlock.ey_tbl_processflowmetaid) {
      console.warn("Could not find GUID for task:", targetKey);
      return;
    }
    const entityName = "ey_tbl_processflowmeta";
    const entityId = targetBlock.ey_tbl_processflowmetaid;

    let baseUrl = '';
    try {
      const pcfContext = context as any as {
        page: {
          getClientUrl: () => string;
          [key: string]: any;
        }
      };
      baseUrl = pcfContext.page.getClientUrl();
    } catch (e) {
      // ignore
    }
    if (!baseUrl) {
      const appUrlProperty = context.parameters as unknown as { BaseAppUrl: { raw: string } };
      baseUrl = appUrlProperty.BaseAppUrl?.raw;
    }
    if (!baseUrl) {
      baseUrl = window.location.origin;
    }
    const cleanBaseUrl = baseUrl.endsWith('/') ? baseUrl.slice(0, -1) : baseUrl;
    const recordUrl = `${cleanBaseUrl}/main.aspx?etn=${entityName}&id=${entityId}&pagetype=entityrecord`;
    window.open(recordUrl, "_blank");
  };

  return (
    <div style={{
      width: "100%",
      height: "100%",
      minHeight: 0,
      boxSizing: "border-box",
      backgroundColor: "#F4F4F4",
      display: "flex",
      flexDirection: "column",
      overflow: "hidden"
    }}>
      {/* Legend & Zoom Toolbar Container */}
      <div style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        margin: "2px 4px 0 4px"
      }}>
        {/* Left: Legend */}
        {selected ? (
          <div style={{
            display: "flex", gap: "16px", padding: "8px 12px",
            background: "#f4f4f4", borderRadius: "8px", alignItems: "center"
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
              <div style={{ width: 16, height: 16, border: `2px solid ${highlightMap.selected.bg}`, borderRadius: 4 }}></div>
              <span style={{ fontWeight: 500 }}>Selected</span>
            </div>

            <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
              <div style={{ width: 16, height: 16, border: `2px solid ${highlightMap.precedent.bg}`, borderRadius: 4 }}></div>
              <span style={{ fontWeight: 500 }}>Upstream Preceding Tasks</span>
            </div>

            <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
              <div style={{ width: 16, height: 16, border: `2px solid ${highlightMap.dependent.bg}`, borderRadius: 4 }}></div>
              <span style={{ fontWeight: 500 }}>Downstream Dependent Tasks</span>
            </div>
          </div>
        ) : <div />
        }

        {/* Right: Zoom Controls */}
        <div style={{
          display: "flex", gap: "8px", background: "#fff", padding: "4px", borderRadius: "8px", boxShadow: "0 1px 3px rgba(0,0,0,0.1)"
        }}>
          <button
            onClick={handleZoomOut}
            disabled={zoom <= 0.3}
            style={{
              width: "32px", height: "32px", cursor: zoom <= 0.3 ? "default" : "pointer",
              border: "1px solid #ccc", borderRadius: "4px", background: "#f9f9f9", fontSize: "18px",
              display: "flex", alignItems: "center", justifyContent: "center", color: "#333", opacity: zoom <= 0.3 ? 0.5 : 1
            }} title="Zoom Out">
            −
          </button>

          <div style={{ display: "flex", alignItems: "center", fontSize: "14px", fontWeight: 600, minWidth: "40px", justifyContent: "center" }}>
            {Math.round(zoom * 100)}%
          </div>

          <button
            onClick={handleZoomIn}
            disabled={zoom >= 2.0}
            style={{
              width: "32px", height: "32px", cursor: zoom >= 2.0 ? "default" : "pointer",
              border: "1px solid #ccc", borderRadius: "4px", background: "#f9f9f9", fontSize: "18px",
              display: "flex", alignItems: "center", justifyContent: "center", color: "#333", opacity: zoom >= 2.0 ? 0.5 : 1
            }} title="Zoom In">
            +
          </button>
        </div>
      </div>

      {/* Main Grid Wrapper */}
      <div style={{
        position: "relative",
        flex: "1 1 auto",
        minHeight: 0,
        margin: "4px 4px",
        background: "#fff",
        borderRadius: "12px",
        boxShadow: "0 2px 8px rgba(0,0,0,0.08)",
        display: "flex",
        flexDirection: "column",
        overflow: "hidden"
      }} role="region" aria-label="Process flow grid">

        {/* Unified Scroll Container (Grid) */}
        <div
          ref={gridContainerRef}
          style={{
            flex: 1,
            width: "100%",
            height: "100%",
            overflow: "auto",
            display: "grid",
            gridTemplateColumns: gridTemplateColumns,
            gridTemplateRows: gridTemplateRows,
            position: "relative",
            gap: "0px 20px"
          }}
        >
          {/* SVG Overlay */}
          <div style={{ gridColumn: "1 / -1", gridRow: "1 / -1", pointerEvents: "none", zIndex: 0, position: "relative", width: "100%", height: "100%" }}>
            <div style={{ position: "absolute", top: 0, left: 0, width: "100%", height: "100%" }}>
              {Object.keys(blockPositions).length > 0 && (
                <FlowConnectorsSVG
                  dependencies={dependencies}
                  blockPositions={blockPositions}
                  selectedDependencyKey={selectedDependencyKey}
                  onSelectDependency={(k) => setSelectedDependencyKey(k)}
                  precedentTaskIds={precedentTaskIds}
                  dependentTaskIds={dependentTaskIds}
                  selectedTaskKey={selected}
                />
              )}
            </div>
          </div>

          {/* === Header Row === */}
          <div style={{
            gridRow: 1, gridColumn: 1,
            position: "sticky", top: 0,
            left: 0,
            zIndex: 40,
            background: "#fff",
            borderRight: "1px solid #ddd",
            borderBottom: "1px solid #ddd",
            rubyPosition: "relative",
            overflow: "hidden",
            backgroundImage: "linear-gradient(to top right, transparent calc(50% - 0.5px), #ddd 50%, transparent calc(50% + 0.5px))",
          }}>
            <div style={{
              position: "absolute",
              top: 10,
              right: 10,
              fontWeight: 600,
              color: "#555",
              fontSize: "13px",
              textAlign: "right",
            }}>
              Working Day
            </div>

            <div style={{
              position: "absolute",
              bottom: 10,
              left: 10,
              fontWeight: 600,
              color: "#555",
              fontSize: "13px",
              textAlign: "left",
            }}>
              Category
            </div>
          </div>

          {/* 2. Timeline Headers */}
          {timelineColumns.map((tl, i) => (
            <div key={`header-${tl}`} style={{
              gridRow: 1, gridColumn: i + 2,
              position: "sticky", top: 0,
              zIndex: 30,
              background: "#fff",
              padding: "10px",
              textAlign: "center",
              borderBottom: "1px solid #ddd"
            }}>
              <div style={{
                fontWeight: 600, color: "#0078D4", fontSize: 17,
                background: "#F4F4F4", borderRadius: "4px", padding: "10px",
                boxShadow: "0 1px 2px rgba(0,0,0,0.06)"
              }}>
                {tl}
              </div>
            </div>
          ))}

          {/* === Data Rows === */}
          {swimlaneLabels.map((rowLabel, rIdx) => (
            <React.Fragment key={`row-${rowLabel}`}>
              {/* 3. Swimlane Label */}
              <div style={{
                gridRow: rIdx + 2, gridColumn: 1,
                position: "sticky",
                left: 0,
                zIndex: 20,
                background: "#fff",
                borderRight: "1px solid #ddd",
                display: "flex", alignItems: "center",
                justifyContent: "flex-start",
                paddingLeft: 12,
                height: "100%",
                fontWeight: 500, color: "#2F2F2F", fontSize: 17
              }}>
                <span style={{ fontSize: "16px", fontWeight: 500 }}>{rowLabel}</span>
              </div>

              {/* 4. Grid Cells */}
              {timelineColumns.map((col, cIdx) => {
                const blocks = stepBlocks.filter(b => b.swimlane === rIdx && b.timeline === cIdx);

                return (
                  <div key={`${rowLabel}-${col}`} style={{
                    gridRow: rIdx + 2, gridColumn: cIdx + 2,
                    height: "100%",
                    display: "flex", flexDirection: "row", alignItems: "center",
                    justifyContent: blocks.length > 0 ? "flex-start" : "center",
                    paddingLeft: blocks.length > 0 ? 8 : 0,
                    paddingRight: blocks.length > 0 ? 8 : 0,
                    overflow: "visible",
                    position: "relative",
                    zIndex: 10
                  }}>
                    {blocks.map((block, idx) => {
                      const isSelected = block.key === selected;
                      const isPrecedent = precedentTaskIds.has(block.key);
                      const isDependent = dependentTaskIds.has(block.key);

                      const border = isSelected ? `3px solid ${highlightMap.selected.bg}`
                        : isPrecedent ? `3px solid ${highlightMap.precedent.bg}`
                          : isDependent ? `3px solid ${highlightMap.dependent.bg}`
                            : `3px solid #fff`;

                      return (
                        <div
                          key={block.key}
                          style={{
                            width: `${scaledCardWidth}px`,
                            minWidth: `${scaledCardWidth}px`,
                            height: `${scaledCardHeight}px`,
                            marginRight: idx < blocks.length - 1 ? `${scaledGap}px` : 0,
                            background: colorMap[block.color].bg,
                            color: colorMap[block.color].fg,
                            border,
                            borderRadius: "16px",
                            boxShadow: isSelected ? "0 0 0 4px #0078D4" : "0 2px 8px rgba(0,0,0,0.10)",
                            position: "relative",
                            boxSizing: "border-box",
                            cursor: "pointer",
                            overflow: "hidden",
                            zIndex: isSelected ? 5 : 2,

                            display: "flex",
                            flexDirection: "column",
                            alignItems: "center",
                            justifyContent: "center",
                            textAlign: "center",

                            paddingLeft: `${20 * zoom}px`,
                            paddingRight: `${10 * zoom}px`,
                            paddingBottom: `${8 * zoom}px`,
                            paddingTop: `${(6 + 4) * zoom}px`
                          }}
                          onClick={() => {
                            setSelected(prev => (prev === block.key ? null : block.key));
                            setHasUserSelected(true);
                          }}
                          ref={boxRefs.current[block.key] ?? (boxRefs.current[block.key] = React.createRef())}
                        >
                          {/* === PENCIL BUTTON (opens menu overlay) === */}
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              e.preventDefault();
                              const rect = (e.currentTarget as HTMLButtonElement).getBoundingClientRect();
                              const MENU_WIDTH = 160;
                              const left =rect.right + window.scrollX + 6;
                              const top = rect.top + window.scrollY;
                              setMenuPos({ x: left, y: top });
                              setMenuForKey(block.key);
                              setMenuGuid(block.ey_tbl_processflowmetaid ?? null);
                            }}
                            style={{
                              position: "absolute",
                              top: `${6 * zoom}px`,
                              right: `${6 * zoom}px`,
                              width: `${26 * zoom}px`,
                              height: `${26 * zoom}px`,
                              borderRadius: `${4 * zoom}px`,
                              border: "1px solid #ccc",
                              background: "Transparent",
                              display: "flex",
                              alignItems: "center",
                              justifyContent: "center",
                              fontSize: `${14 * zoom}px`,
                              cursor: "pointer",
                              padding: 0,
                              lineHeight: 0,
                              zIndex: 10
                            }}
                            title="More actions"
                            aria-label="More actions"
                          >
                            ✏️
                          </button>

                          {/* === CENTERED TEXT STACK === */}
                          <div
                            style={{
                              width: "100%",
                              maxWidth: "100%",
                              display: "flex",
                              flexDirection: "column",
                              alignItems: "center",
                              justifyContent: "center",
                              gap: `${4 * zoom}px`,
                              paddingRight: `${(26 + 12) * zoom}px`
                            }}
                          >
                            <span
                              title={block.title}
                              style={{
                                display: "-webkit-box",
                                WebkitLineClamp: 2,
                                WebkitBoxOrient: "vertical",
                                overflow: "hidden",
                                textOverflow: "ellipsis",
                                whiteSpace: "normal",
                                wordBreak: "break-word",
                                fontSize: `${Math.max(10, 14 * zoom)}px`,
                                fontWeight: 700,
                                lineHeight: 1.2,
                                maxWidth: "100%",
                                textAlign: "center"
                              }}
                            >
                              {block.title}
                            </span>

                            <span
                              style={{
                                display: "-webkit-box",
                                WebkitLineClamp: 2,
                                WebkitBoxOrient: "vertical",
                                overflow: "hidden",
                                whiteSpace: "normal",
                                wordBreak: "break-word",
                                fontSize: `${Math.max(9, 12 * zoom)}px`,
                                opacity: 0.9,
                                lineHeight: 1.25,
                                maxWidth: "100%",
                                textAlign: "center"
                              }}
                            >
                              {block.subtitle}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                );
              })}
            </React.Fragment>
          ))}
        </div>
      </div>

      {/* Details Panel - STATIC SIZE (Not Affected by Zoom) */}
      {selectedBlock && (
        <div style={{
          margin: "0 4px 4px 4px",
          background: "#ffffff",
          borderRadius: "12px",
          boxShadow: "0 2px 8px rgba(0,0,0,0.05)",
          padding: "20px 28px",
          border: "1px solid #e2e2e2",
          flexShrink: 0,
          fontSize: "15px",
          color: "#333",
          textAlign: "left"
        }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", cursor: "pointer", marginBottom: "12px" }} onClick={() => setIsOpen(!isOpen)}>
            <div style={{ fontSize: "18px", fontWeight: 600 }}>
              Task: {selectedBlock.title} : {selectedBlock.subtitle}
            </div>
            <div style={{ fontSize: "14px", color: "#0078D4", alignContent: "center" }}>{isOpen ? "Collapse ▼" : "Expand ▲"}</div>
          </div>

          {isOpen && (
            <div>
              <div style={{ lineHeight: "22px", marginBottom: "12px" }}>
                <div><strong>Category:</strong> {selectedBlock.swimlaneLabel}</div>
                <div><strong>Working Day:</strong> {selectedBlock.workingDay}</div>
                <div><strong>Status:</strong> <span style={{
                  color: standardStatusColors[selectedBlock.color],
                  fontWeight: 600
                }}>{selectedBlock.CurrentStatusText}</span></div>
              </div>

              <div style={{ marginTop: "6px" }}><strong>Upstream Preceding Tasks:</strong></div>
              {!Array.from(precedentTaskIds).length ? <div style={{ color: "#777" }}>None</div> : (
                <ul style={{ paddingLeft: "20px", marginTop: "4px" }}>
                  {Array.from(precedentTaskIds).map(id => {
                    const block = stepBlocks.find(b => b.key === id);
                    const label = block ? (block.subtitle ?? block.title) : id;
                    const statusText = block ? block.CurrentStatusText : 'N/A';
                    const workingDayText = block ? `WD ${block.workingDay ?? 'N/A'}` : 'N/A';
                    const displayInfo = `${statusText}; ${workingDayText}`;

                    return (
                      <li key={id} style={{ fontSize: "14px", marginBottom: "4px" }}>
                        <span
                          onClick={() => void handleOpenRecord(id)}
                          style={{ cursor: "pointer", color: "#0078D4", textDecoration: "underline" }}
                          role="link"
                          tabIndex={0}
                          onKeyDown={(e) => { if (e.key === "Enter") handleOpenRecord(id); }}
                        >
                          {id}: {label} ({displayInfo})
                        </span>
                      </li>
                    );
                  })}
                </ul>
              )}

              <div style={{ marginTop: "16px" }}><strong>Downstream Dependent Tasks:</strong></div>
              {!Array.from(dependentTaskIds).length ? <div style={{ color: "#777" }}>None</div> : (
                <ul style={{ paddingLeft: "20px", marginTop: "4px" }}>
                  {Array.from(dependentTaskIds).map(id => {
                    const block = stepBlocks.find(b => b.key === id);
                    const label = block ? (block.subtitle ?? block.title) : id;
                    const statusText = block ? block.CurrentStatusText : 'N/A';
                    const workingDayText = block ? `WD ${block.workingDay ?? 'N/A'}` : 'N/A';
                    const displayInfo = `${statusText}; ${workingDayText}`;

                    return (
                      <li key={id} style={{ fontSize: "14px", marginBottom: "4px" }}>
                        <span
                          onClick={() => void handleOpenRecord(id)}
                          style={{ cursor: "pointer", color: "#0078D4", textDecoration: "underline" }}
                          role="link"
                          tabIndex={0}
                          onKeyDown={(e) => { if (e.key === "Enter") handleOpenRecord(id); }}
                        >
                          {id}: {label} ({displayInfo})
                        </span>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>
          )}
        </div>
      )}
{/* === MENU OVERLAY (outside grid; fixed, un-clipped) === */}
      {menuForKey && (
        <div
          ref={menuRef}
          style={{
            position: "fixed",
            left: menuPos.x,
            top: menuPos.y,
            zIndex: 999999,
            background: "#fff",
            border: "1px solid #ddd",
            borderRadius: 8,
            boxShadow: "0 6px 18px rgba(0,0,0,0.18)",
            minWidth: 160,
            padding: "6px 0"
          }}
          role="menu"
          aria-label="Card actions"
          onClick={(e) => e.stopPropagation()}
        >
          {MENU_ITEMS.map((item) => (
            <div
              key={item}
              role="menuitem"
              tabIndex={0}
              onClick={() => {
                if (menuGuid) {
                  onPcfMenuPick({ id: menuGuid, action: item });
                }
              }}
              onKeyDown={(e) => {
                if ((e.key === "Enter" || e.key === " ") && menuGuid) {
                  e.preventDefault();
                  onPcfMenuPick({ id: menuGuid, action: item });
                }
              }}
              style={{
                padding: "8px 12px",
                cursor: "pointer",
                fontSize: 13,
                display: "flex",
                alignItems: "center",
                gap: 8
              }}
              onMouseEnter={(e) => (e.currentTarget.style.background = "#f5f5f5")}
              onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
            >
              {item}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ProcessFlow;
