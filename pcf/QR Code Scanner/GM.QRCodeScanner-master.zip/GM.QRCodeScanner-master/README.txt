================================================================================
  QR CODE STYLING - PCF Control for Power Apps
  Version 1.0.0.0
================================================================================

OVERVIEW
--------
QR Code Styling is a Power Apps Component Framework (PCF) field-level control
that generates styled QR codes with full customization of shapes, colors,
gradients, and center logo images.

It is built on top of the open-source library "qr-code-styling" by Denys Kozak
(https://github.com/kozakdenys/qr-code-styling).

The control works on both Model-driven apps and Canvas apps.


FEATURES
--------
- Bind to any Single Line Text field to encode its value as a QR code
- Editable text input integrated in the control (type or paste the value)
- 6 dot styles: square, dots, rounded, classy, classy-rounded, extra-rounded
- 3 corner square styles: square, dot, extra-rounded
- 2 corner dot styles: square, dot
- 2 QR shapes: square, circle
- Full color customization for dots, corners, and background
- Linear and radial gradient support on dots
- Center logo/image with configurable size, margin, and background dot hiding
- 4 error correction levels: L (7%), M (15%), Q (25%), H (30%)
- Responsive: adapts to the allocated container size
- Respects field security (disabled / read-only states)
- SVG rendering for crisp output at any resolution


PROPERTIES
----------
  Name                    Type          Default      Description
  ---------------------   -----------   ----------   ---------------------------
  qrData                  Bound Text    (none)       Text or URL to encode
  qrSize                  Whole Number  300          QR code size in pixels
  qrMargin                Whole Number  0            Margin around QR code (px)
  qrShape                 Enum          square       Overall shape (square|circle)
  errorCorrectionLevel    Enum          Q            Error correction (L|M|Q|H)
  dotsType                Enum          square       Dot style
  dotsColor               Text          #000000      Dot color (hex)
  backgroundColor         Text          #FFFFFF      Background color or "transparent"
  cornersSquareType       Enum          square       Corner square style
  cornersSquareColor      Text          (dots color) Corner square color (hex)
  cornersDotType          Enum          square       Corner dot style
  cornersDotColor         Text          (dots color) Corner dot color (hex)
  imageUrl                Text          (none)       URL of logo image
  imageSize               Text          0.4          Logo size coefficient (0.1-0.5)
  imageMargin             Whole Number  5            Logo margin in pixels
  hideBackgroundDots      Enum          true         Hide dots behind logo (Yes|No)
  dotsGradientType        Enum          none         Gradient type (none|linear|radial)
  dotsGradientColor1      Text          #000000      Gradient start color
  dotsGradientColor2      Text          #000000      Gradient end color
  dotsGradientRotation    Whole Number  0            Gradient rotation in degrees


INSTALLATION
------------
1. Import the solution zip (managed or unmanaged) into your Power Platform
   environment via make.powerapps.com > Solutions > Import Solution.
2. For Model-driven apps: add the control to a Single Line Text field on any
   entity form.
3. For Canvas apps: Insert > Get more components > Code > QR Code Styling.


================================================================================
  CONFIGURATION TESTS
================================================================================

TEST 1 - Basic QR Code (Model-driven)
--------------------------------------
  Goal:     Verify the control renders a default QR code.
  Setup:    Add the control to a text field on an Account form.
            Configure only the required "qrData" property (bind to the field).
            Save and publish the form.
  Steps:    1. Open an Account record.
            2. Type "https://www.microsoft.com" in the input field.
            3. Verify a black-on-white square QR code appears below the input.
            4. Scan the QR code with a phone camera.
  Expected: The QR code renders at 300x300px. Scanning opens the Microsoft URL.


TEST 2 - Styled Dots and Colors
--------------------------------
  Goal:     Verify dot styles and custom colors work.
  Config:   dotsType        = rounded
            dotsColor       = #4267b2
            backgroundColor = #e9ebee
            cornersSquareType  = extra-rounded
            cornersSquareColor = #1a3a6b
            cornersDotType     = dot
            cornersDotColor    = #1a3a6b
  Steps:    1. Open a record and enter any URL.
            2. Verify dots are rounded and blue (#4267b2).
            3. Verify corner squares are extra-rounded and dark blue.
            4. Verify background is light gray (#e9ebee).
            5. Scan the QR code.
  Expected: All styling is applied. QR code is scannable.


TEST 3 - Center Logo Image
---------------------------
  Goal:     Verify a logo image renders in the center of the QR code.
  Config:   imageUrl           = https://upload.wikimedia.org/wikipedia/commons/5/51/Facebook_f_logo_%282019%29.svg
            imageSize          = 0.3
            imageMargin        = 10
            hideBackgroundDots = Yes
            errorCorrectionLevel = H
  Steps:    1. Enter "https://www.facebook.com" in the field.
            2. Verify the Facebook logo appears in the center.
            3. Verify dots behind the logo are hidden (clean area).
            4. Scan the QR code.
  Expected: Logo is centered with margin. QR code is scannable (H level).


TEST 4 - Linear Gradient on Dots
----------------------------------
  Goal:     Verify gradient rendering on QR dots.
  Config:   dotsGradientType     = linear
            dotsGradientColor1   = #ff0000
            dotsGradientColor2   = #0000ff
            dotsGradientRotation = 90
            dotsType             = rounded
  Steps:    1. Enter any text in the field.
            2. Verify dots transition from red (top) to blue (bottom).
            3. Scan the QR code.
  Expected: Vertical gradient from red to blue is visible. QR is scannable.


TEST 5 - Radial Gradient on Dots
----------------------------------
  Goal:     Verify radial gradient works.
  Config:   dotsGradientType   = radial
            dotsGradientColor1 = #00ff00
            dotsGradientColor2 = #000000
  Steps:    1. Enter any text in the field.
            2. Verify dots show a radial gradient from green (center) to black.
  Expected: Radial gradient renders correctly.


TEST 6 - Circle Shape
-----------------------
  Goal:     Verify the circle QR shape.
  Config:   qrShape  = circle
            dotsType = dots
  Steps:    1. Enter any URL in the field.
            2. Verify the QR code has a circular shape with random extra dots
               around the edges.
            3. Scan the QR code.
  Expected: Circular QR code renders. Scannable.


TEST 7 - Custom Size and Margin
---------------------------------
  Goal:     Verify size and margin configuration.
  Config:   qrSize   = 200
            qrMargin = 20
  Steps:    1. Enter any URL.
            2. Verify the QR code renders at 200x200px with visible margin.
  Expected: QR code is smaller than default with padding around it.


TEST 8 - Transparent Background
---------------------------------
  Goal:     Verify transparent background support.
  Config:   backgroundColor = transparent
            dotsColor       = #34a853
  Steps:    1. Enter any URL.
            2. Verify the QR code has no visible background (transparent).
            3. Verify dots are green.
  Expected: QR code floats on the form background with no white box.


TEST 9 - Canvas App Integration
---------------------------------
  Goal:     Verify the control works in Canvas apps.
  Steps:    1. Create a new Canvas app.
            2. Insert > Get more components > Code > QR Code Styling.
            3. Add the control to the screen.
            4. Set qrData = "https://www.google.com"
            5. Set dotsType = "rounded"
            6. Set dotsColor = "#4285f4"
            7. Add a TextInput and bind: QRCodeStyling1.qrData = TextInput1.Text
            8. Type a URL in the TextInput.
  Expected: QR code updates in real time as the user types.


TEST 10 - Dynamic Update (Canvas)
-----------------------------------
  Goal:     Verify real-time QR code generation from a TextInput.
  Steps:    1. In a Canvas app, add a TextInput and the QR Code Styling control.
            2. Bind qrData to TextInput1.Text.
            3. Type "Hello World" in the TextInput.
            4. Change it to "https://github.com".
            5. Clear the TextInput.
  Expected: QR code regenerates on each keystroke. When empty, shows the
            placeholder message "Enter a value to generate a QR code".


TEST 11 - Empty Field / Placeholder
--------------------------------------
  Goal:     Verify behavior when no data is provided.
  Steps:    1. Open a record with an empty text field.
            2. Verify the control shows "Enter a value to generate a QR code".
            3. Type a value. Verify the QR code appears.
            4. Clear the field. Verify the placeholder returns.
  Expected: Placeholder shown when empty. No errors in the browser console.


TEST 12 - Read-Only and Disabled States
-----------------------------------------
  Goal:     Verify the control respects field security.
  Steps:    1. Set the text field to read-only via field security profile.
            2. Open the record.
            3. Verify the input field is grayed out and not editable.
            4. Verify the QR code still renders from the existing value.
  Expected: Input is read-only. QR code displays. No editing possible.


TEST 13 - Error Correction Levels
------------------------------------
  Goal:     Verify all error correction levels render valid QR codes.
  Config:   Test each level: L, M, Q, H
            Use imageUrl with a logo for H level.
  Steps:    1. Set errorCorrectionLevel = L. Enter a URL. Scan.
            2. Change to M. Scan.
            3. Change to Q. Scan.
            4. Change to H. Add a logo. Scan.
  Expected: All levels produce scannable QR codes. H level supports the logo
            with the most redundancy.


TEST 14 - Responsive Resize (Model-driven)
---------------------------------------------
  Goal:     Verify the QR code adapts to container size changes.
  Steps:    1. Open a record with the control on a form.
            2. Resize the browser window (make it narrow, then wide).
            3. Verify the QR code scales within its container.
  Expected: QR code resizes without overflow or clipping.


TEST 15 - All Dot Types Visual Verification
----------------------------------------------
  Goal:     Verify each dot type renders correctly.
  Steps:    For each dot type, update dotsType and verify:
            1. square         - sharp square dots
            2. dots           - circular dots
            3. rounded        - rounded square dots
            4. classy         - classy pattern dots
            5. classy-rounded - classy with rounded edges
            6. extra-rounded  - very rounded dots
  Expected: Each dot type produces a visually distinct QR code style.


================================================================================
  NOTES
================================================================================

- When using a center logo image, always set errorCorrectionLevel to H for
  best scannability.
- Keep imageSize at 0.3 or below for reliable scanning.
- The imageUrl must be accessible (CORS-enabled) for the logo to render.
- The control uses SVG rendering for crisp output at any zoom level.
- Bundle size is approximately 103 KB including the qr-code-styling library.

================================================================================
  LICENSE
================================================================================

This control uses the qr-code-styling library (MIT License).
Copyright (c) 2021 Denys Kozak - https://github.com/kozakdenys/qr-code-styling

================================================================================
