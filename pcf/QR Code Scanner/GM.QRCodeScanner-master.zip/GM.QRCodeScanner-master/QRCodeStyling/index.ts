import { IInputs, IOutputs } from "./generated/ManifestTypes";
import QRCodeStylingLib from "qr-code-styling";

export class QRCodeStyling implements ComponentFramework.StandardControl<IInputs, IOutputs> {
    private _container: HTMLDivElement;
    private _qrContainer: HTMLDivElement;
    private _inputElement: HTMLInputElement;
    private _notifyOutputChanged: () => void;
    private _qrCode: InstanceType<typeof QRCodeStylingLib> | null = null;
    private _lastOptionsJson = "";
    private _currentValue: string | null = null;

    constructor() {
        // Empty
    }

    public init(
        context: ComponentFramework.Context<IInputs>,
        notifyOutputChanged: () => void,
        state: ComponentFramework.Dictionary,
        container: HTMLDivElement
    ): void {
        context.mode.trackContainerResize(true);
        this._notifyOutputChanged = notifyOutputChanged;

        this._container = container;
        this._container.style.width = "100%";
        this._container.style.height = "100%";

        const wrapper = document.createElement("div");
        wrapper.className = "gm-qrcode-styling-wrapper";
        this._container.appendChild(wrapper);

        this._inputElement = document.createElement("input");
        this._inputElement.className = "gm-qrcode-styling-input";
        this._inputElement.type = "text";
        this._inputElement.placeholder = "Enter text or URL for QR code...";
        this._inputElement.addEventListener("input", this._onInputChange.bind(this));
        wrapper.appendChild(this._inputElement);

        this._qrContainer = document.createElement("div");
        this._qrContainer.className = "gm-qrcode-styling-container";
        wrapper.appendChild(this._qrContainer);
    }

    private _onInputChange(): void {
        this._currentValue = this._inputElement.value || null;
        this._notifyOutputChanged();
    }

    public updateView(context: ComponentFramework.Context<IInputs>): void {
        const data = context.parameters.qrData?.raw;
        const isDisabled = context.mode.isControlDisabled;
        const securityEditable = context.parameters.qrData.security?.editable;
        const isReadOnly = securityEditable === false;

        this._inputElement.disabled = isDisabled;
        this._inputElement.readOnly = isReadOnly;

        if (this._currentValue === null && data !== this._inputElement.value) {
            this._inputElement.value = data ?? "";
        }
        this._currentValue = null;

        const valueToRender = this._inputElement.value;

        if (!valueToRender) {
            this._qrContainer.innerHTML = "";
            this._qrContainer.className = "gm-qrcode-styling-placeholder";
            this._qrContainer.textContent = "Enter a value to generate a QR code";
            this._qrCode = null;
            this._lastOptionsJson = "";
            return;
        }

        this._qrContainer.className = "gm-qrcode-styling-container";

        const options = this._buildOptions(context, valueToRender);
        const optionsJson = JSON.stringify(options);

        if (optionsJson === this._lastOptionsJson) {
            return;
        }
        this._lastOptionsJson = optionsJson;

        this._qrContainer.innerHTML = "";
        this._qrCode = new QRCodeStylingLib(options as ConstructorParameters<typeof QRCodeStylingLib>[0]);
        this._qrCode.append(this._qrContainer);
    }

    public getOutputs(): IOutputs {
        return {
            qrData: this._inputElement.value || undefined
        };
    }

    public destroy(): void {
        this._inputElement.removeEventListener("input", this._onInputChange.bind(this));
        if (this._qrContainer) {
            this._qrContainer.innerHTML = "";
        }
        this._qrCode = null;
    }

    private _buildOptions(context: ComponentFramework.Context<IInputs>, data: string): Record<string, unknown> {
        const params = context.parameters;

        const size = params.qrSize?.raw ?? 300;
        const margin = params.qrMargin?.raw ?? 0;

        const allocatedWidth = context.mode.allocatedWidth > 0 ? context.mode.allocatedWidth : size;
        const allocatedHeight = context.mode.allocatedHeight > 0 ? context.mode.allocatedHeight : size;
        const effectiveSize = Math.min(size, allocatedWidth, allocatedHeight);

        const shape = params.qrShape?.raw ?? "square";
        const errorCorrectionLevel = params.errorCorrectionLevel?.raw ?? "Q";
        const dotsType = params.dotsType?.raw ?? "square";
        const dotsColor = params.dotsColor?.raw ?? "#000000";
        const backgroundColor = params.backgroundColor?.raw ?? "#FFFFFF";
        const cornersSquareType = params.cornersSquareType?.raw ?? "square";
        const cornersSquareColor = params.cornersSquareColor?.raw;
        const cornersDotType = params.cornersDotType?.raw ?? "square";
        const cornersDotColor = params.cornersDotColor?.raw;
        const imageUrl = params.imageUrl?.raw;
        const imageSizeStr = params.imageSize?.raw ?? "0.4";
        const imageSize = parseFloat(imageSizeStr) || 0.4;
        const imageMargin = params.imageMargin?.raw ?? 5;
        const hideBackgroundDots = (params.hideBackgroundDots?.raw ?? "true") === "true";

        const dotsGradientType = params.dotsGradientType?.raw ?? "none";
        const dotsGradientColor1 = params.dotsGradientColor1?.raw ?? "#000000";
        const dotsGradientColor2 = params.dotsGradientColor2?.raw ?? "#000000";
        const dotsGradientRotation = params.dotsGradientRotation?.raw ?? 0;

        // Build dots options
        const dotsOptions: Record<string, unknown> = { type: dotsType };
        if (dotsGradientType !== "none") {
            dotsOptions.gradient = {
                type: dotsGradientType,
                rotation: (dotsGradientRotation * Math.PI) / 180,
                colorStops: [
                    { offset: 0, color: dotsGradientColor1 },
                    { offset: 1, color: dotsGradientColor2 }
                ]
            };
        } else {
            dotsOptions.color = dotsColor;
        }

        // Build corners square options
        const cornersSquareOptions: Record<string, unknown> = { type: cornersSquareType };
        if (cornersSquareColor) {
            cornersSquareOptions.color = cornersSquareColor;
        }

        // Build corners dot options
        const cornersDotOptions: Record<string, unknown> = { type: cornersDotType };
        if (cornersDotColor) {
            cornersDotOptions.color = cornersDotColor;
        }

        // Build background options
        const backgroundOptions: Record<string, unknown> = {};
        if (backgroundColor.toLowerCase() === "transparent") {
            backgroundOptions.color = "transparent";
        } else {
            backgroundOptions.color = backgroundColor;
        }

        // Build image options
        const imageOptions: Record<string, unknown> = {
            hideBackgroundDots: hideBackgroundDots,
            imageSize: imageSize,
            margin: imageMargin,
            crossOrigin: "anonymous"
        };

        const options: Record<string, unknown> = {
            width: effectiveSize,
            height: effectiveSize,
            type: "svg",
            data: data,
            margin: margin,
            shape: shape,
            qrOptions: {
                errorCorrectionLevel: errorCorrectionLevel
            },
            dotsOptions: dotsOptions,
            backgroundOptions: backgroundOptions,
            cornersSquareOptions: cornersSquareOptions,
            cornersDotOptions: cornersDotOptions,
            imageOptions: imageOptions
        };

        if (imageUrl) {
            options.image = imageUrl;
        }

        return options;
    }
}
